AJOKE SALON WEBSITE
====================

Files:
- index.html  -> main website
- style.css   -> design and responsive mobile styling
- script.js   -> mobile menu and current year

Business details used:
- Salon: Ajoke Salon
- Client: Akoke
- Phone: 09162714456
- Email: Timileyinadewuyi208@gmail.com
- Location: Ikeja, Lagos
- Specialty: Modern hairstyles

To publish:
1. Upload index.html, style.css and script.js to GitHub.
2. Enable GitHub Pages.
3. Your site will be available at the GitHub Pages address.

Replace the four gallery placeholders with real salon photos when available.
